// import { Toast } from 'bootstrap.min.js'
// const MyCarusel = document.getElementsByClassName('swiper-comment__carusel')[0];
// const carousel = new bootstrap.Carousel(MyCarusel, {
//     interval: 4000,
//     touch: true,
//     ride: carousel

// })